import { createContext } from 'react';
const LoginContext = createContext({});
export default LoginContext;
